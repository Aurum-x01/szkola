
async function getData() {
    // for(i=0; i>-1; i++){
    var input = document.querySelector("#x").value
    const response = await fetch(`http://localhost:3001/kwadrat/${input}`)
    const json = await response.json()
    document.querySelector("p").innerHTML=json.wynik

    console.log(json)
    // }
}

async function kolo() {
    // for(i=0; i>-1; i++){
    var input = document.querySelector("#x").value
    const response = await fetch(`http://localhost:3001/kolo/${input}`)
    const json = await response.json()
    document.querySelector("p").innerHTML=json.wynik

    console.log(json)
    // }
}
async function kolo() {
    // for(i=0; i>-1; i++){
    var input = document.querySelector("#x").value
    const response = await fetch(`http://localhost:3001/kolo/${input}`)
    const json = await response.json()
    document.querySelector("p").innerHTML=json.wynik

    console.log(json)
    // }
}
async function random() {
    // for(i=0; i>-1; i++){
    const min = parseInt(document.querySelector("#min").value)
    const max = parseInt(document.querySelector("#max").value)

    console.log(min, max)
    const response = await fetch(`http://localhost:3001/losuj/${min}/${max}`)
    const json = await response.json()
    document.querySelector("h5").innerHTML=json.wynik

    console.log(json)
    // }
}
async function potega() {
    // for(i=0; i>-1; i++){
    const liczba = parseInt(document.querySelector("#min").value)
    const wykladnik = parseInt(document.querySelector("#max").value)

    console.log(liczba, wykladnik)
    const response = await fetch(`http://localhost:3001/potega/${liczba}/${wykladnik}`)
    const json = await response.json()
    document.querySelector("h5").innerHTML=json.wynik

    console.log(json)
    // }
}