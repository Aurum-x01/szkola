// for(i=0; i<=100; i++){
//     console.log(i)
// }
// console.log("Hello World")
// var a = 5
// var b = 15
// var text = "Włodek"
// console.log("Twoje imie sklada się z "+text.length+" znaków")
// console.log("Dodawanie: ", a+b)

const express = require("express")
const cors = require("cors")
const app = express()
const port = 3001

app.use(cors())

app.get('/', (req, res) => {
  res.send('Volodymyr Pestrak')
})
app.get("/index.html", (req, res) => {
  res.sendFile(__dirname + "/client/index.html");
});
app.get('/klasa', (req, res) => {
  console.log('zapytanie klasa')
  res.send('2PRO')
})

app.get('/text/:wartosc/:wartosc2', (req, res)=>{
const wartosc = req.params.wartosc
const wartosc2 = req.params.wartosc2
res.json(
  {
    wynik: `${wartosc} ${wartosc2}`
  }
)
})
app.get('/kwadrat/:x', (req, res)=>{
const x = req.params.x
console.log(`Kwadrat liczby ${x} wynosi ${x*x}`)
res.json(
  {
    wynik: x*x
  }
)
})


app.get('/kolo/:r', (req, res)=>{
const r = req.params.r
const p = 3.14
console.log(`Koło o promieniu: ${r} ma pole ${p*r**2}`)
res.json(
  {
    wynik: p*r**2
  }
)
})

app.get('/losuj/:min/:max', (req, res)=>{
const min = parseInt(req.params.min)+1
const max = parseInt(req.params.max)+1
const rand = Math.floor(Math.random () * (max - min + 1) + min)

console.log(`Liczba ${rand} zgenerowana jest z zakresu od ${min} do ${max}`)
res.json(
  {
    wynik: rand
  }
)
})

app.get('/potega/:liczba/:wykladnik', (req, res)=>{

const liczba = parseInt(req.params.liczba)
const wykladnik = parseInt(req.params.wykladnik)
const wynik = Math.pow(liczba, wykladnik)

console.log(`Liczba ${liczba} do potęgi ${wykladnik} = ${wynik}`)
res.json(
  {
    wynik: wynik
  }
)
})
// app.get('/pierwsza/:n', (req, res)=>{

// const number = parseInt(req.params.n)

// function trialDivision(number) {
//     for (let i = 2; i < number; i++) {
//         if (number % i === 0) {
//             return false;
//         }
//     }
//     return true;
//   res.json(
//     {
//     wynik: 
//     }
// )
// }


// }

// )

app.listen(port)    

