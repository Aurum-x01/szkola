async function zarejestruj() {
    var login = document.querySelector("#login").value
    var password = document.querySelector("#password").value
    const span = document.querySelector("#result")

    const response = await fetch(`http://localhost:3000/dodaj/${login}/${password}`)
    const json = await response.json()
    span.innerHTML=json.wynik
}


async function zaloguj() {
    var login = document.querySelector("#login").value
    var password = document.querySelector("#password").value
    const span = document.querySelector("#result")

    const response = await fetch(`http://localhost:3000/zaloguj/${login}/${password}`)
    const json = await response.json()
    span.innerHTML=json.wynik
}



function pokaz(){
    const password =document.querySelector("#password")
    const pokaz = document.querySelector("#pokaz")
    if(password.type === "password"){
        password.setAttribute("type", "text")
        pokaz.innerHTML="🔓"
    }else{
        password.setAttribute("type", "password")
        pokaz.innerHTML="🔒"
    }
}