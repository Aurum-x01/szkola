const express = require("express")
const cors = require("cors")
const mysql = require("mysql")
const md5 = require("md5")
const app = express()
const port = 3000
app.use(cors())


let con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "users"
})

con.connect(function (err) {
    if (err) {
        console.log("baza nie działa")
    } else {
        const sql = `update accounts set online = 0`
        con.query(sql, function (err, result) {
            if (err) {
                console.log("baza nie działa")
            } else {
                console.log("baza działa")
            }
        })

    }
})

app.get('/dodaj/:login/:password', (req, res) => {
    const login = req.params.login
    const password = md5(req.params.password)

    let sql = `Select * from accounts where login = '${login}'`
    console.log(sql)

    con.query(sql, function (err, result) {
        if (err) {
            console.log("Problem połączenia z bazą!")
            console.log(err)
            res.json({
                wynik: "Problem połączenia z bazą!"
            })
        } else {
            if (result.length > 0) {
                res.json({ wynik: "Użytkownik o takim loginie już istnieje" })
            } else {
                const sql1 = `INSERT INTO accounts (login, password, typ) values ('${login}', '${password}', 'użytkownik')`
                con.query(sql1, function (err, result) {
                    if (err) {
                        console.log("Użytkownika nie dodano")
                    } else {
                        console.log("Użytkownika dodano")
                        res.json({ wynik: "użytkownika dodano" })
                    }
                })
            }
        }

    })
})

app.get('/zaloguj/:login/:password', (req, res) => {
    const login = req.params.login
    const password = md5(req.params.password)

    let sql = `select * from accounts where login = '${login}' and password='${password}'`
    con.query(sql, function (err, result) {
        if (err) {
            console.log("ERROR")
            res.json({
                wynik: "Nie udało się zalogować"
            })
        } else {

            let sql1 = `update accounts set online = 1 where login='${login}'`
            con.query(sql1, function (err, result) {
                if (err) {
                    console.log("error")
                }
                else {
                    console.log("Jesteś zalogowany")
                    res.json({
                        wynik: "Zalogowano poprawnie"
                    })
                    let sql2 = `select * from accounts where login = '${login}' and typ='admin'`
                    con.query(sql2, function(err,result){
                        if(err){
                            console.log("ERROR")
                        }else{
                            
                        }
                    })
                }
            })


        }
    })

})

app.listen(port, () => {
    console.log("Serwer działa")
})