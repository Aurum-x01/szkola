const body1 = document.querySelector("body")
function menu() {

    const status = JSON.parse(localStorage.getItem("logowanie"))
    console.log(status)
    const user_info_div = document.createElement("div")
    const img_icon = document.createElement("img")
    const user_info_paragraph = document.createElement("p")
    const header = document.createElement("header")
    const h1 = document.createElement("h1")
    const button_client = document.createElement("button")
    const button_workman = document.createElement("button")
    const button_admin = document.createElement("button")
    const button_logout = document.createElement("button")

    user_info_paragraph.innerHTML = `ID: ${status.id} | Login: ${status.login}`

    user_info_div.style.display = "flex"
    user_info_div.style.marginLeft = "10px"
    user_info_div.style.textDecoration = "underline"
    user_info_div.style.alignItems="center"

    user_info_paragraph.style.marginLeft = "10px"

    button_logout.title = "Wylogować się"
    img_icon.setAttribute("src", "img/icon_client.png")
    img_icon.style.width = "40px"
    img_icon.style.height = "40px"

    h1.innerHTML = "Menu"

    button_client.innerHTML = "Client"
    button_workman.innerHTML = "Pracownik"
    button_admin.innerHTML = "Admin Panel"

    const img_logout = document.createElement("img")
    img_logout.setAttribute("src", "img/logout.png")
    img_logout.style.width = '40px'
    img_logout.style.height = '40px'




    if (status?.status != "ok") {

    } else {
        body1.prepend(header)
        header.appendChild(button_logout)
        button_logout.appendChild(img_logout)
    }

    //admin
    if (status?.status != "ok" || (status?.privilege == "0" || status?.privilege == "1")) {

    } else {
        body1.prepend(header)
        header.appendChild(user_info_div)
        user_info_div.appendChild(img_icon)
        user_info_div.appendChild(user_info_paragraph)
        header.appendChild(h1)
        header.appendChild(button_client)
        header.appendChild(button_workman)
        header.appendChild(button_admin)
    }
    //user
    if (status?.status != "ok" || (status?.privilege == "2" || status?.privilege == "1")) {

    } else {
        body1.prepend(header)
        header.appendChild(user_info_div)
        user_info_div.appendChild(img_icon)
        user_info_div.appendChild(user_info_paragraph)
        header.appendChild(h1)
        header.appendChild(button_client)
    }
    //workman
    if (status?.status != "ok" || (status?.privilege == "0" || status?.privilege == "2")) {

    } else {
        body1.prepend(header)
        header.appendChild(user_info_div)
        user_info_div.appendChild(img_icon)
        user_info_div.appendChild(user_info_paragraph)
        header.appendChild(h1)
        header.appendChild(button_client)
        header.appendChild(button_workman)

    }

    button_logout.addEventListener("click", () => {
        localStorage.removeItem("logowanie")
        location.reload()

    })

    const main1 = document.createElement("main")

    main1.setAttribute("id", "room_reservation")

    header.setAttribute("id", "header_menu")
    button_logout.setAttribute("id", "button_logout")

    button_client.addEventListener("click", () => {
        window.location.href = "client.html"
    })
    button_workman.addEventListener("click", () => {
        window.location.href = "workman.html"
    })
    button_admin.addEventListener("click", () => {
        window.location.href = "admin_panel.html"
    })




    body1.appendChild(main1)
}

menu()