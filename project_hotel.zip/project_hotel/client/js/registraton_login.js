async function registration() {
    const login = document.querySelector("#login").value
    const password = document.querySelector("#password").value

    const response = await fetch(`http://localhost:3000/registration/${login}/${password}`)
    const json = await response.json()
    if (json.status == "err") {
        document.querySelector("#status").innerHTML = "Dane nie zostały przesłane (ERROR)"
    } else {
        document.querySelector("#status").innerHTML = "Dane zostały przesłane"
    }
}

async function zaloguj() {
    const login = document.querySelector("#login").value
    const password = document.querySelector("#password").value


    const response = await fetch(`http://localhost:3000/sign_in/${login}/${password}`)
    const json = await response.json()
    console.log(json)
    if (json.status == "err") {
        document.querySelector("#status").innerHTML = "Nie udało się zalogować"

    } else {
        document.querySelector("#status").innerHTML = "Zalogowano"
        localStorage.setItem("logowanie", JSON.stringify(json))
        setTimeout(() => {
            window.location.href = "client.html";
        }, 2000)


    }

}


function haslo() {
    if (document.querySelector("#password").type === "password") {
        document.querySelector("#password").setAttribute("type", "text")
        document.querySelector("#hidden_unhidden_img").setAttribute("src", "img/unhidden.png")

    } else {
        document.querySelector("#password").setAttribute("type", "password")
        document.querySelector("#hidden_unhidden_img").setAttribute("src", "img/hidden.png")
    }
}
const btn = document.querySelector("#zaloguj")
function change_registration() {
    const h3 = document.querySelector("#textH3")
    const changeBtn = document.querySelector("#change_btn")


    if (h3.textContent === "Logowanie") {
        h3.textContent = "Rejestracja"
        btn.textContent = "Zarejestruj się"
        btn.setAttribute("onclick", "registration()")
        changeBtn.textContent = "Masz konto? Zaloguj się"
    } else {
        h3.textContent = "Logowanie"
        btn.textContent = "Zaloguj się"
        btn.setAttribute("onclick", "zaloguj()")
        changeBtn.textContent = "Nie masz konta? Zarejestruj się"
    }
}
const body = document.querySelector("body")
body.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
        const h3 = document.querySelector("#textH3")
        if (h3.textContent === "Logowanie") {
            zaloguj()
        } else {
            registration()
        }
    }
});
