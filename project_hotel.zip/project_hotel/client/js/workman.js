async function reservations_show() {
    const all_reservations = document.querySelector("#all_reservations")
    const response = await fetch("http://localhost:3000/reservations_show")
    const json = await response.json()

    all_reservations.innerHTML = ""

    for (let i = 0; i < json.reservations.length; i++) {
        const div_res = document.createElement("div")
        div_res.style.marginTop = "10px"
        const info = document.createElement("p")
        const btn_del = document.createElement("button")
        const btn_ch = document.createElement("button")

        div_res.setAttribute("id", "div_res")

        info.innerHTML = `ID:${json.reservations[i].id} | User:${json.reservations[i].login} | Apartament:${json.reservations[i].apartment_number} | ${json.reservations[i].date_in.slice(0, 10)}→${json.reservations[i].date_out.slice(0, 10)}`

        btn_del.innerHTML = "Usuń"
        btn_ch.innerHTML = "Zmień"
        btn_del.type = btn_ch.type = "button"

        btn_del.addEventListener("click", async () => {
            if (confirm("Chcesz usunąć tę rezerwację?")) {
                await fetch(`http://localhost:3000/reservation_delete/${json.reservations[i].id}`, { method: "DELETE" })
                div_res.remove()
            }
        });

        btn_ch.addEventListener("click", async () => {

            const div_change = document.createElement("div")
            div_change.setAttribute("id", "div_change_reservation")
            div_change.style.border = "1px solid #aaa"
            div_change.style.padding = "10px"
            div_change.style.margin = "5px 0"
            div_change.style.background = "#131313"
            div_change.style.borderRadius = "20px"
            div_change.style.position = "fixed"
            div_change.style.flexDirection = "column"
            div_change.style.display = "flex"
            div_change.style.justifyContent = "center"
            div_change.style.alignItems = "center"
            div_change.style.padding = "40px"

            const p = document.createElement("p")
            p.innerHTML = "❌"
            p.style.position = "absolute"
            p.style.right = "10px"
            p.style.top = "0px"
            p.style.cursor = "pointer"
            p.addEventListener("click", () => {
                div_change.removeChild(label_user)
                div_change.removeChild(inp_user)
                div_change.removeChild(label_room)
                div_change.removeChild(inp_room)
                div_change.removeChild(label_date_in)
                div_change.removeChild(inp_date_in)
                div_change.removeChild(label_date_out)
                div_change.removeChild(inp_date_out)
                div_change.removeChild(btn_save)
                div_change.removeChild(p)
                div_change.remove()
                tlo.remove()
            })
            div_change.appendChild(p)

            const today = new Date()
            const sixMonthsLater = new Date()
            sixMonthsLater.setMonth(today.getMonth() + 6)
            const formatDate = (date) => date.toISOString().split('T')[0]

            const label_user = document.createElement("label")
            label_user.innerHTML = "User ID: "
            const inp_user = document.createElement("input")
            inp_user.value = json.reservations[i].id_user

            const label_room = document.createElement("label")
            label_room.innerHTML = "ID Apartment: "
            const inp_room = document.createElement("input")
            inp_room.value = json.reservations[i].id_room

            const label_date_in = document.createElement("label")
            label_date_in.innerHTML = "Date in: "
            const inp_date_in = document.createElement("input")
            inp_date_in.min = formatDate(today)
            inp_date_in.max = formatDate(sixMonthsLater)
            inp_date_in.type = "date"


            const label_date_out = document.createElement("label")
            label_date_out.innerHTML = "Date out: "
            const inp_date_out = document.createElement("input")
            inp_date_out.min = formatDate(today)
            inp_date_out.max = formatDate(sixMonthsLater)
            inp_date_out.type = "date"

            const btn_save = document.createElement("button")
            btn_save.type = "button"
            btn_save.innerHTML = "Zapisz"

            div_change.appendChild(label_user)
            div_change.appendChild(inp_user)
            div_change.appendChild(document.createElement("br"))
            div_change.appendChild(label_room)
            div_change.appendChild(inp_room)
            div_change.appendChild(document.createElement("br"))
            div_change.appendChild(label_date_in)
            div_change.appendChild(inp_date_in)
            div_change.appendChild(document.createElement("br"))
            div_change.appendChild(label_date_out)
            div_change.appendChild(inp_date_out)
            div_change.appendChild(document.createElement("br"))
            div_change.appendChild(btn_save)

            const tlo = document.createElement("div")
            tlo.style.position = "fixed"
            tlo.style.top = "0"
            tlo.style.left = "0"
            tlo.style.right = "0"
            tlo.style.bottom = "0"
            tlo.style.width = "100%"
            tlo.style.height = "100vh"
            tlo.style.backgroundColor = "rgba(0, 0, 0, 0.6)"
            tlo.style.zIndex = "9998"
            tlo.style.display = "flex"
            tlo.style.justifyContent = "center"
            tlo.style.alignItems = "center"
            document.querySelector("body").appendChild(tlo)

            tlo.appendChild(div_change)



            btn_save.addEventListener("click", async () => {
                await fetch(`http://localhost:3000/reservation_update/${json.reservations[i].id}/${inp_user.value}/${inp_room.value}/${inp_date_in.value}/${inp_date_out.value}`)

                info.innerHTML = `ID:${json.reservations[i].id} | User:${inp_user.value} | Apart:${inp_room.value} | ${inp_date_in.value}→${inp_date_out.value}`
                tlo.remove()
                div_change.remove()
            })
        })


        div_res.append(info, btn_del, btn_ch)
        all_reservations.appendChild(div_res)
    }
}

reservations_show()
