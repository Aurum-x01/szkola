async function add_room() {
    const inp_floor = document.querySelector("#inp_floor").value
    const inp_rooms = document.querySelector("#inp_rooms").value
    const inp_num_ap = document.querySelector("#inp_num_ap").value

    const response = await fetch(`http://localhost:3000/add_room/${inp_floor}/${inp_rooms}/${inp_num_ap}`)
    const json = await response.json()
    if (json.status == "err") {
        document.querySelector("#status").innerHTML = "Dane nie zostały przesłane (ERROR)"
    } else {
        document.querySelector("#status").innerHTML = "Dane zostały przesłane"
    }
}

async function pokoje() {
    const all_apartment = document.querySelector("#all_apartment")
    const response = await fetch(`http://localhost:3000/rooms_show`)
    const json = await response.json()
    console.log(json)

    for (let i = 0; i < json.room.length; i++) {
        console.log("+")
        const div_room = document.createElement("div")
        div_room.classList.add("div_pokoje")

        const pNum = document.createElement("p")
        const pRoom = document.createElement("p")
        const pFloor = document.createElement("p")
        const button = document.createElement("button")
        const btn_ch = document.createElement("button")


        btn_ch.innerHTML = "zmienić"
        button.innerHTML = "usunąć"
        // console.log(json.room[i].id_room)



        button.addEventListener("click", async () => {
            const ask = confirm("Chcesz usunąć ten apartament?")

            if (ask == true) {
                await fetch(`http://localhost:3000/room_delete/${json.room[i].id_room}`, {
                    method: "DELETE"
                })

                div_room.remove()
            }
        })



        btn_ch.addEventListener("click", async () => {
            const p = document.createElement("p")
            p.innerHTML = "❌"
            p.style.position = "absolute"
            p.style.right = "10px"
            p.style.top = "0px"
            p.style.cursor = "pointer"

            p.addEventListener("click", () => {

                tlo.remove()
            })

            const div_change_record = document.createElement("div")
            const label_floor = document.createElement("label")
            const inp_ch_floor = document.createElement("input")
            const label_room = document.createElement("label")
            const inp_ch_rooms = document.createElement("input")
            const label_nr_ap = document.createElement("label")
            const inp_ch_nr_ap = document.createElement("input")
            const btn_save = document.createElement("button")

            div_change_record.setAttribute("id", "div_change_record")

            inp_ch_floor.value = json.room[i].floor
            inp_ch_rooms.value = json.room[i].rooms
            inp_ch_nr_ap.value = json.room[i].apartment_number

            label_floor.innerHTML="Piętro: "
            label_room.innerHTML="Pokoje: "
            label_nr_ap.innerHTML="Numer apartamentu: "

            btn_save.innerHTML = "zapisz"
            const tlo = document.createElement("div")
            tlo.setAttribute("id", "tlo")
            tlo.style.position = "fixed"
            tlo.style.top = "0"
            tlo.style.left = "0"
            tlo.style.right = "0"
            tlo.style.bottom = "0"
            tlo.style.width = "100%"
            tlo.style.height = "100vh"
            tlo.style.backgroundColor = "rgba(0, 0, 0, 0.6)"
            tlo.style.zIndex = "9998"
            tlo.style.display = "flex"
            tlo.style.justifyContent = "center"
            tlo.style.alignItems = "center"
            document.querySelector("body").appendChild(tlo)


            tlo.appendChild(div_change_record)
            div_change_record.appendChild(p)
            div_change_record.appendChild(label_floor)
            div_change_record.appendChild(inp_ch_floor)
            div_change_record.appendChild(label_room)
            div_change_record.appendChild(inp_ch_rooms)
            div_change_record.appendChild(label_nr_ap)
            div_change_record.appendChild(inp_ch_nr_ap)
            div_change_record.appendChild(btn_save)

            btn_save.addEventListener("click", async () => {
                await fetch(`http://localhost:3000/update/${inp_ch_nr_ap.value}/${inp_ch_rooms.value}/${inp_ch_floor.value}/${json.room[i].id_room}`)

                pNum.innerHTML = `Numer pokoju: ${inp_ch_nr_ap.value}`
                pRoom.innerHTML = `Ilość pokojów: ${inp_ch_rooms.value}`
                pFloor.innerHTML = `Piętro: ${inp_ch_floor.value}`

                div_change_record.remove()
            })
        })


        pNum.innerHTML = `Numer pokoju: ${json.room[i].apartment_number}`
        pRoom.innerHTML = `Ilość pokojów: ${json.room[i].rooms}`
        pFloor.innerHTML = `Piętro: ${json.room[i].floor}`



        all_apartment.appendChild(div_room)
        div_room.appendChild(pNum)
        div_room.appendChild(pRoom)
        div_room.appendChild(pFloor)
        div_room.appendChild(button)
        div_room.appendChild(btn_ch)
    }

}

async function reservations_show() {
    const all_reservations = document.querySelector("#all_reservations")
    const response = await fetch("http://localhost:3000/reservations_show")
    const json = await response.json()

    all_reservations.innerHTML = ""

    for (let i = 0; i < json.reservations.length; i++) {
        const div_res = document.createElement("div")
        div_res.style.marginTop = "10px"
        const info = document.createElement("p")
        const btn_del = document.createElement("button")
        const btn_ch = document.createElement("button")

        div_res.setAttribute("id", "div_res")

        info.innerHTML = `ID:${json.reservations[i].id} | User:${json.reservations[i].login} | Apartament:${json.reservations[i].apartment_number} | ${json.reservations[i].date_in.slice(0, 10)}→${json.reservations[i].date_out.slice(0, 10)}`

        btn_del.innerHTML = "Usuń"
        btn_ch.innerHTML = "Zmień"
        btn_del.type = btn_ch.type = "button"

        btn_del.addEventListener("click", async () => {
            if (confirm("Chcesz usunąć tę rezerwację?")) {
                await fetch(`http://localhost:3000/reservation_delete/${json.reservations[i].id}`, { method: "DELETE" })
                div_res.remove()
                
            }
        });

        btn_ch.addEventListener("click", async () => {

            const div_change = document.createElement("div")
            div_change.setAttribute("id", "div_change_reservation")
            div_change.style.border = "1px solid #aaa"
            div_change.style.padding = "10px"
            div_change.style.margin = "5px 0"
            div_change.style.background = "#131313"
            div_change.style.borderRadius = "20px"
            div_change.style.position = "fixed"
            div_change.style.flexDirection = "column"
            div_change.style.display = "flex"
            div_change.style.justifyContent = "center"
            div_change.style.alignItems = "center"
            div_change.style.padding = "40px"

            const p = document.createElement("p")
            p.innerHTML = "❌"
            p.style.position = "absolute"
            p.style.right = "10px"
            p.style.top = "0px"
            p.style.cursor = "pointer"
            p.addEventListener("click", () => {
                div_change.removeChild(label_user)
                div_change.removeChild(inp_user)
                div_change.removeChild(label_room)
                div_change.removeChild(inp_room)
                div_change.removeChild(label_date_in)
                div_change.removeChild(inp_date_in)
                div_change.removeChild(label_date_out)
                div_change.removeChild(inp_date_out)
                div_change.removeChild(btn_save)
                div_change.removeChild(p)
                div_change.remove()
                tlo.remove()
            })
            div_change.appendChild(p)


            const label_user = document.createElement("label")
            label_user.innerHTML = "User ID: "
            const inp_user = document.createElement("input")
            inp_user.value = json.reservations[i].id_user

            const label_room = document.createElement("label")
            label_room.innerHTML = "ID Apartment: "
            const inp_room = document.createElement("input")
            inp_room.value = json.reservations[i].id_room

            const label_date_in = document.createElement("label")
            label_date_in.innerHTML = "Date in: "
            const inp_date_in = document.createElement("input")
            inp_date_in.type = "date"
            inp_date_in.value = json.reservations[i].date_in;

            const label_date_out = document.createElement("label")
            label_date_out.innerHTML = "Date out: "
            const inp_date_out = document.createElement("input")
            inp_date_out.type = "date"
            inp_date_out.value = json.reservations[i].date_out

            const btn_save = document.createElement("button")
            btn_save.type = "button"
            btn_save.innerHTML = "Zapisz"

            div_change.appendChild(label_user)
            div_change.appendChild(inp_user)
            div_change.appendChild(document.createElement("br"))
            div_change.appendChild(label_room)
            div_change.appendChild(inp_room)
            div_change.appendChild(document.createElement("br"))
            div_change.appendChild(label_date_in)
            div_change.appendChild(inp_date_in)
            div_change.appendChild(document.createElement("br"))
            div_change.appendChild(label_date_out)
            div_change.appendChild(inp_date_out)
            div_change.appendChild(document.createElement("br"))
            div_change.appendChild(btn_save)

            const tlo = document.createElement("div")
            tlo.style.position = "fixed"
            tlo.style.top = "0"
            tlo.style.left = "0"
            tlo.style.right = "0"
            tlo.style.bottom = "0"
            tlo.style.width = "100%"
            tlo.style.height = "100vh"
            tlo.style.backgroundColor = "rgba(0, 0, 0, 0.6)"
            tlo.style.zIndex = "9998"
            tlo.style.display = "flex"
            tlo.style.justifyContent = "center"
            tlo.style.alignItems = "center"
            document.querySelector("body").appendChild(tlo)

            tlo.appendChild(div_change)



            btn_save.addEventListener("click", async () => {
                await fetch(`http://localhost:3000/reservation_update/${json.reservations[i].id}/${inp_user.value}/${inp_room.value}/${inp_date_in.value}/${inp_date_out.value}`)

                info.innerHTML = `ID:${json.reservations[i].id} | User:${inp_user.value} | Apart:${inp_room.value} | ${inp_date_in.value}→${inp_date_out.value}`

                div_change.remove()
                tlo.remove()
            })
        })


        div_res.append(info, btn_del, btn_ch)
        all_reservations.appendChild(div_res)
    }
}





pokoje()
reservations_show()
