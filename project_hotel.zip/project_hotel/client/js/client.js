const body = document.querySelector("body")
const main = document.querySelector("main")

async function getRoom() {
    const response = await fetch(`http://localhost:3000/reservation`)
    const json_response = await response.json()

    console.log(json_response)



    for (i = 0; i < json_response.status.length; i++) {
        const div_room = document.createElement("div")
        const p_ap_num = document.createElement("p")
        const p_floor = document.createElement("p")
        const p_rooms = document.createElement("p")
        const btn_zar = document.createElement("button")

        div_room.classList.add("div_room")
        div_room.setAttribute("data-room-id", `${json_response.status[i].id_room}`)


        p_ap_num.style.textAlign = "left"
        p_floor.style.textAlign = "center"
        p_rooms.style.textAlign = "right"
        btn_zar.style.textAlign = "right"


        const img_zar = document.createElement("img")
        img_zar.setAttribute("src", "img/reserwation.png")
        img_zar.style.width = '30px'
        img_zar.style.height = '30px'


        btn_zar.setAttribute("value", `${json_response.status[i].apartment_number}`)

        p_ap_num.textContent = `Numer apartamentu: ${json_response.status[i].apartment_number}`
        p_floor.textContent = `Piętro: ${json_response.status[i].floor}`
        p_rooms.textContent = `Ilość pokojów: ${json_response.status[i].rooms}`


        btn_zar.addEventListener("click", () => {
            const today = new Date()
            const sixMonthsLater = new Date()
            sixMonthsLater.setMonth(today.getMonth() + 6)
            const formatDate = (date) => date.toISOString().split('T')[0]


            const tlo = document.createElement("div")
            const div_window_rez = document.createElement("div")
            const close = document.createElement("p")
            const p_text = document.createElement("p")
            const date_on = document.createElement("label")
            const input_date_on = document.createElement("input")
            input_date_on.min = formatDate(today)
            input_date_on.max = formatDate(sixMonthsLater)
            const date_out = document.createElement("label")
            const input_date_out = document.createElement("input")
            input_date_out.min = formatDate(today)
            input_date_out.max = formatDate(sixMonthsLater)
            const Zarezerwowac = document.createElement("button")
            div_window_rez.style.color = "white"
            div_window_rez.style.display = "flex"
            div_window_rez.style.zIndex = 9999
            div_window_rez.style.flexDirection = "column"
            div_window_rez.setAttribute("id", "div_windows_rez")
            div_window_rez.style.position = "fixed"


            tlo.style.position = "fixed"
            tlo.style.top = "0"
            tlo.style.left = "0"
            tlo.style.right = "0"
            tlo.style.bottom = "0"
            tlo.style.width = "100%"
            tlo.style.height = "100vh"
            tlo.style.backgroundColor = "rgba(0, 0, 0, 0.6)"
            tlo.style.zIndex = "9998"
            tlo.style.display = "flex"
            tlo.style.alignItems = "center"
            tlo.style.justifyContent = "center"

            p_text.innerHTML = `Zarezerwować apartament numer: ${btn_zar.value}`

            date_on.innerHTML = "Data wjazdu:"
            date_on.setAttribute("for", "date_on")

            date_on.addEventListener('input', function (e) {
                var day = new Date(this.value).getUTCDay();
                if ([6, 0].includes(day)) {
                    e.preventDefault();
                    this.value = '';
                    alert('Weekends not allowed');
                }
            });



            date_out.innerHTML = "Data wyjazdu:"
            date_out.setAttribute("for", "date_out")
            input_date_on.setAttribute("type", "date")
            input_date_on.setAttribute("id", "date_on")
            input_date_out.setAttribute("type", "date")
            input_date_out.setAttribute("id", "date_out")

            close.innerHTML = "❌"
            close.style.cursor = "pointer"
            close.style.position = "absolute"
            close.style.top = "0px"
            close.style.right = "10px"

            Zarezerwowac.innerHTML = "Zarezerwować"
            Zarezerwowac.style.alignSelf = "center"
            Zarezerwowac.style.marginTop = "15px"

            Zarezerwowac.addEventListener("click", async () => {
                const json_login = localStorage.getItem("logowanie")
                let date_login = null
                console.log(json_login)
                if (json_login) {
                    date_login = JSON.parse(json_login)
                    console.log(date_login?.id)
                }

                const response_json = await fetch(`http://localhost:3000/reservation_room/${div_room.getAttribute("data-room-id")}/${date_login?.id}/${input_date_on.value}/${input_date_out.value}`)
                const json = await response_json.json()

                location.reload()
            }
            )

            close.addEventListener("click", () => {
                body.removeChild(tlo)
                tlo.removeChild(div_window_rez)
                div_window_rez.removeChild(close)
                div_window_rez.removeChild(p_text)
                div_window_rez.removeChild(date_on)
                div_window_rez.removeChild(input_date_on)
                div_window_rez.removeChild(date_out)
                div_window_rez.removeChild(input_date_out)
                div_window_rez.removeChild(Zarezerwowac)
            })

            div_window_rez.style.backgroundColor = "#131313"
            div_window_rez.style.padding = "30px"
            div_window_rez.style.borderRadius = "20px"

            body.appendChild(tlo)
            tlo.appendChild(div_window_rez)
            div_window_rez.appendChild(close)
            div_window_rez.appendChild(p_text)
            div_window_rez.appendChild(date_on)
            div_window_rez.appendChild(input_date_on)
            div_window_rez.appendChild(date_out)
            div_window_rez.appendChild(input_date_out)
            div_window_rez.appendChild(Zarezerwowac)

        })

        main.appendChild(div_room)
        div_room.appendChild(p_ap_num)
        div_room.appendChild(p_floor)
        div_room.appendChild(p_rooms)
        div_room.appendChild(btn_zar)
        btn_zar.appendChild(img_zar)
    }


}

getRoom()