// 0-users; 1-workman; 2-admin

function check_login() {
    const status = JSON.parse(localStorage.getItem("logowanie"))
    console.log(status)

    const location = window.location.href


    if (status?.status != "ok") {
        window.location.href = "index.html"
    }

    if (status?.status != "ok" || (location.includes("workman.html") && status?.privilege == "0")) {
        window.location.href = "index.html"
    } else {

    }

    if (status?.status != "ok" || (location.includes("admin_panel.html") && (status?.privilege == "0" || status?.privilege == "1"))) {
        window.location.href = "index.html"
    } else {

    }
    if (status?.status != "ok" || (location.includes("client.html") && (status?.privilege == ""))) {
        window.location.href = "index.html"
    } else {

    }

    if (status?.status != "ok") {
        window.location.href = "index.html"
    } else {

    }
}
check_login()