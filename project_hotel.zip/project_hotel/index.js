const express = require("express")
const cors = require("cors")
const md5 = require("md5")
const mysql = require("mysql")
const app = express()
const port = 3000
app.use(cors())

let con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "hotel"
});

con.connect(function (err) {
    if (err) {
        console.log("problem połączenia z bazą")
    } else {
        console.log("Baza działą")
    }
})

app.get("/registration/:login/:password", (req, res) => {
    const login = req.params.login
    const password = md5(req.params.password)

    let check = `select * from users where login="${login}"`
    con.query(check, function (err, result) {
        if (err) {
            console.log("Użytkownika nie dodano (Problem z bazą)")
            res.json(
                {
                    status: "err"
                }
            )
        } else {
            if (result.length > 0) {
                console.log("Taki użytkownik już istnieje")
                res.json(
                    {
                        status: "err"
                    }
                )
            } else {
                let sql = `INSERT INTO users (login, password) values ("${login}","${password}")`
                con.query(sql, function (err, result) {
                    if (err) {
                        console.log("Użytkownika nie dodano")
                        res.json(
                            {
                                status: "err"
                            }
                        )
                    } else {
                        res.json({
                            status: "ok"
                        })
                        console.log("Dodano nowego użytkownika")
                    }
                })
            }
        }
    })

})


app.get("/sign_in/:login/:password", (req, res) => {
    const login = req.params.login
    const password = md5(req.params.password)

    let sql = `select * from users where login="${login}" and password="${password}"`
    con.query(sql, function (err, result) {
        if (err) {
            console.log("Problem z logowaniem")
            res.json(
                {
                    status: "err"
                }
            )
        } else {
            if (result.length > 0) {
                console.log("Zalogowano poprawnie")
                res.json(
                    {
                        status: "ok", id: `${result[0].ID}`, login: `${result[0].login}`, privilege: `${result[0].privilege}`
                    }
                )
            } else {
                console.log("Nie udało sie zalogować")
                res.json(
                    {
                        status: "err"
                    }
                )
            }
        }
    })
})


app.get("/add_room/:floor/:rooms/:apartment_number", (req, res) => {
    const floor = req.params.floor
    const rooms = req.params.rooms
    const apartment_number = req.params.apartment_number

    let check = `select * from apartment where apartment_number="${apartment_number}"`
    con.query(check, function (err, result) {
        if (err) {
            console.log("Pokój nie został dodany (Problem z bazą)")
            res.json(
                {
                    status: "err"
                }
            )
        } else {
            if (result.length > 0) {
                console.log("Taki pokój już istnieje")
                res.json(
                    {
                        status: "err"
                    }
                )
            } else {
                let sql = `INSERT INTO apartment (floor, rooms, apartment_number) values ("${floor}","${rooms}", "${apartment_number}")`
                con.query(sql, function (err, result) {
                    if (err) {
                        console.log("Pokój nie został dodany")
                        res.json(
                            {
                                status: "err"
                            }
                        )
                    } else {
                        res.json({
                            status: "ok"
                        })
                        console.log("Dodano nowy pokój")
                    }
                })
            }
        }
    })

})

app.get("/rooms_show", (req, res) => {
    let sql = "Select * from apartment";
    con.query(sql, function (err, result) {
        if (err) {
            console.log("Dane o pokojach nie zostaly pobrane")
        } else {
            console.log("Dane o pokojach zostaly pobrane")
            console.log(result)
            res.json(
                {
                    room: result
                }
            )
        }
    })
})

app.delete("/room_delete/:room_id", (req, res) => {
    const room_id = req.params.room_id

    let sql = `DELETE FROM apartment WHERE id_room = ${room_id}`
    con.query(sql, function (err, result) {
        if (err) {
            console.log("Nie usunięto")
        }

        res.json(
            {
                success: true
            }
        )
    })
})


app.get("/update/:nr_ap/:rooms/:floor/:id_room", (req, res) => {
    const nr_ap = req.params.nr_ap
    const rooms = req.params.rooms
    const floor = req.params.floor
    const id_room = req.params.id_room

    let sql = `update apartment set floor=${floor}, rooms=${rooms}, apartment_number=${nr_ap} where id_room=${id_room}`
    con.query(sql, function (err, result) {
        if (err) {
            console.log("Nie zmieniono")
        }

        res.json(
            {
                status: "Dane o pokoju zostały zmienione"
            }
        )
    })
})



app.get("/reservation", (req, res) => {
    let sql = `Select apartment.* from apartment left join reservations on apartment.id_room = reservations.id_room where reservations.id_room is null `

    con.query(sql, function (err, result) {
        if (err) {
            console.log("Nie udało się pobrać danych" + err)
        } else {
            res.json(
                {
                    status: result
                }
            )
        }
    })
})



app.get("/reservation_room/:room_id/:user_id/:date_in/:date_out", (req, res) => {
    const room_id = req.params.room_id
    const user_id = req.params.user_id
    const date_in = req.params.date_in
    const date_out = req.params.date_out

    let sql = `INSERT INTO reservations (id_user, id_room, date_in, date_out) values (${user_id}, ${room_id}, "${date_in}", "${date_out}")`
    con.query(sql, function (err, result) {
        if (err) {
            console.log("Nie usunięto")
            console.log(err)
            console.log(sql)
        } else {
            console.log("Zarezerwowano")

            res.json(
                {
                    result: result
                }

            )
        }
    })
})

app.get("/update/:nr_ap/:rooms/:floor/:id_room", (req, res) => {
    const nr_ap = req.params.nr_ap
    const rooms = req.params.rooms
    const floor = req.params.floor
    const id_room = req.params.id_room

    let sql = `update apartment set floor=${floor}, rooms=${rooms}, apartment_number=${nr_ap} where id_room=${id_room}`
    con.query(sql, function (err, result) {
        if (err) {
            console.log("Nie zmieniono")
        }

        res.json(
            {
                status: "Dane o pokoju zostały zmienione"
            }
        )
    })
})

app.get("/reservations_show", (req, res) => {
    let sql = `SELECT reservations.id, reservations.id_user, reservations.id_room, reservations.date_in, reservations.date_out, apartment.apartment_number, users.login FROM reservations LEFT JOIN apartment ON reservations.id_room = apartment.id_room LEFT JOIN users ON reservations.id_user = users.ID`

    con.query(sql, function (err, result) {
        if (err) {
            console.log("Nie udało się pobrać rezerwacji", err)
            res.json(
                {
                    status: "err"
                }
            )
        } else {
            res.json(
                {
                    reservations: result
                }
            )
        }
    })
})

app.delete("/reservation_delete/:reservation_id", (req, res) => {
    const reservation_id = req.params.reservation_id;

    let sql = `DELETE FROM reservations WHERE id = ${reservation_id}`
    con.query(sql, function (err, result) {
        if (err) {
            console.log("Nie usunięto rezerwacji", err)
            res.json({ success: false })
        } else {
            res.json({ success: true })
        }
    })
})

app.get("/reservation_update/:id/:id_user/:id_room/:date_in/:date_out", (req,res)=>{
    const id = req.params.id
    const id_user = req.params.id_user
    const id_room = req.params.id_room
    const date_in = req.params.date_in
    const date_out = req.params.date_out

    let sql = `UPDATE reservations SET id_user=${id_user}, id_room=${id_room}, date_in='${date_in}', date_out='${date_out}' WHERE id=${id}`;
    con.query(sql,function(err,result){
        if(err){
            console.log("Nie zmieniono rezerwacji", err)
            res.json({status:"err"})
        } else {
            res.json({status:"ok"})
        }
    })
})




app.listen(port, () => {
    console.log("Serwer działa")
})