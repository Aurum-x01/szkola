async function hash() {
    const input = document.querySelector("#password").value
    console.log(input)
    const response = await fetch(`http://localhost:3000/zamien/${input}`)
    const json = await response.json()
    console.log(json)
    document.querySelector("#wynik").innerHTML=json.wynik
}