const express = require("express")
const cors = require("cors")
const md5 = require("md5")
const app = express()

app.use(cors())
const port =3000

app.get('/zamien/:password', (req,res)=>{
    const password = md5(req.params.password)
    res.json({
        wynik: password
    })
})

app.listen(port, ()=>{
    console.log("serwer działa")
})
